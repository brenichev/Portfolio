﻿
namespace EventsTest
{
    partial class EditForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainTables = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.EventsControl = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.Savebutton1 = new System.Windows.Forms.Button();
            this.EventDesc = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.EventLink = new System.Windows.Forms.TextBox();
            this.FormComboBox = new System.Windows.Forms.ComboBox();
            this.AgeComboBox = new System.Windows.Forms.ComboBox();
            this.FormIdBox = new System.Windows.Forms.Label();
            this.AgeIdBox = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TypeIdBox = new System.Windows.Forms.ComboBox();
            this.EventName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.EventDesc2 = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.EventLink2 = new System.Windows.Forms.TextBox();
            this.FormComboBox2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.AgeComboBox2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TypeIdBox2 = new System.Windows.Forms.ComboBox();
            this.EventName2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SaveButton2 = new System.Windows.Forms.Button();
            this.DeleteButton1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.StagesControl = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.StageName1 = new System.Windows.Forms.TextBox();
            this.EventsComboBox1 = new System.Windows.Forms.ComboBox();
            this.SaveButtonStages1 = new System.Windows.Forms.Button();
            this.StageDesc1 = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.CostNumeric1 = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.dateTimeFinish1 = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.AdressComboBox1 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.StageNumeric1 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dateTimeStart1 = new System.Windows.Forms.DateTimePicker();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.SaveButtonStages2 = new System.Windows.Forms.Button();
            this.DeleteButtonStages = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.StageDesc2 = new System.Windows.Forms.RichTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.CostNumeric2 = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.StageName2 = new System.Windows.Forms.TextBox();
            this.EventsComboBox2 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.AdressComboBox2 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.StageNumeric2 = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.dateTimeFinish2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeStart2 = new System.Windows.Forms.DateTimePicker();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.ManagerDesc1 = new System.Windows.Forms.RichTextBox();
            this.ManagerLink1 = new System.Windows.Forms.TextBox();
            this.ManagerTypeCombo1 = new System.Windows.Forms.ComboBox();
            this.ManagerOtch1 = new System.Windows.Forms.TextBox();
            this.ManagerSurname1 = new System.Windows.Forms.TextBox();
            this.UpdateButtonManager1 = new System.Windows.Forms.Button();
            this.SaveButtonManager1 = new System.Windows.Forms.Button();
            this.DeleteButtonManager1 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.MemberDesc1 = new System.Windows.Forms.RichTextBox();
            this.MemberLink1 = new System.Windows.Forms.TextBox();
            this.MemberTypeCombo1 = new System.Windows.Forms.ComboBox();
            this.MemberOtch1 = new System.Windows.Forms.TextBox();
            this.MemberSurname1 = new System.Windows.Forms.TextBox();
            this.UpdateButtonMember1 = new System.Windows.Forms.Button();
            this.DeleteButtonMember1 = new System.Windows.Forms.Button();
            this.SaveButtonMember1 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.UpdateButtonList1 = new System.Windows.Forms.Button();
            this.DeleteButtonList1 = new System.Windows.Forms.Button();
            this.SaveButtonList1 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.MemberListCombo1 = new System.Windows.Forms.ComboBox();
            this.EventListCombo1 = new System.Windows.Forms.ComboBox();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.HouseText2 = new System.Windows.Forms.TextBox();
            this.HouseText1 = new System.Windows.Forms.TextBox();
            this.ManagerName1 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.UpdateButtonListManager1 = new System.Windows.Forms.Button();
            this.DeleteButtonListMaanger1 = new System.Windows.Forms.Button();
            this.SaveButtonListManager1 = new System.Windows.Forms.Button();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.ManagerPartCombo2 = new System.Windows.Forms.ComboBox();
            this.EventPartCombo2 = new System.Windows.Forms.ComboBox();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.label19 = new System.Windows.Forms.Label();
            this.MemberName1 = new System.Windows.Forms.TextBox();
            this.MainTables.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.EventsControl.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.StagesControl.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CostNumeric1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StageNumeric1)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CostNumeric2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StageNumeric2)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.SuspendLayout();
            // 
            // MainTables
            // 
            this.MainTables.Controls.Add(this.tabPage1);
            this.MainTables.Controls.Add(this.tabPage2);
            this.MainTables.Controls.Add(this.tabPage7);
            this.MainTables.Controls.Add(this.tabPage8);
            this.MainTables.Controls.Add(this.tabPage9);
            this.MainTables.Controls.Add(this.tabPage10);
            this.MainTables.Dock = System.Windows.Forms.DockStyle.Top;
            this.MainTables.Location = new System.Drawing.Point(0, 0);
            this.MainTables.Margin = new System.Windows.Forms.Padding(4);
            this.MainTables.Name = "MainTables";
            this.MainTables.SelectedIndex = 0;
            this.MainTables.Size = new System.Drawing.Size(1200, 606);
            this.MainTables.TabIndex = 1;
            this.MainTables.SelectedIndexChanged += new System.EventHandler(this.MainTables_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.EventsControl);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1192, 575);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Мероприятия";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // EventsControl
            // 
            this.EventsControl.Controls.Add(this.tabPage3);
            this.EventsControl.Controls.Add(this.tabPage4);
            this.EventsControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.EventsControl.Location = new System.Drawing.Point(4, 4);
            this.EventsControl.Margin = new System.Windows.Forms.Padding(4);
            this.EventsControl.Name = "EventsControl";
            this.EventsControl.SelectedIndex = 0;
            this.EventsControl.Size = new System.Drawing.Size(1184, 566);
            this.EventsControl.TabIndex = 2;
            this.EventsControl.Click += new System.EventHandler(this.EventsControl_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.Savebutton1);
            this.tabPage3.Controls.Add(this.EventDesc);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.EventLink);
            this.tabPage3.Controls.Add(this.FormComboBox);
            this.tabPage3.Controls.Add(this.AgeComboBox);
            this.tabPage3.Controls.Add(this.FormIdBox);
            this.tabPage3.Controls.Add(this.AgeIdBox);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.TypeIdBox);
            this.tabPage3.Controls.Add(this.EventName);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1176, 535);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Добавить";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // Savebutton1
            // 
            this.Savebutton1.Location = new System.Drawing.Point(406, 392);
            this.Savebutton1.Margin = new System.Windows.Forms.Padding(4);
            this.Savebutton1.Name = "Savebutton1";
            this.Savebutton1.Size = new System.Drawing.Size(234, 61);
            this.Savebutton1.TabIndex = 12;
            this.Savebutton1.Text = "Сохранить";
            this.Savebutton1.UseVisualStyleBackColor = true;
            this.Savebutton1.Click += new System.EventHandler(this.Savebutton1_Click);
            this.Savebutton1.MouseLeave += new System.EventHandler(this.Savebutton1_MouseLeave);
            // 
            // EventDesc
            // 
            this.EventDesc.Location = new System.Drawing.Point(34, 392);
            this.EventDesc.Margin = new System.Windows.Forms.Padding(4);
            this.EventDesc.Name = "EventDesc";
            this.EventDesc.Size = new System.Drawing.Size(361, 131);
            this.EventDesc.TabIndex = 11;
            this.EventDesc.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 370);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 18);
            this.label6.TabIndex = 10;
            this.label6.Text = "Описание";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 300);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 18);
            this.label5.TabIndex = 9;
            this.label5.Text = "Ссылка на источник";
            // 
            // EventLink
            // 
            this.EventLink.Location = new System.Drawing.Point(34, 323);
            this.EventLink.Margin = new System.Windows.Forms.Padding(4);
            this.EventLink.Name = "EventLink";
            this.EventLink.Size = new System.Drawing.Size(148, 24);
            this.EventLink.TabIndex = 8;
            // 
            // FormComboBox
            // 
            this.FormComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FormComboBox.FormattingEnabled = true;
            this.FormComboBox.Location = new System.Drawing.Point(34, 258);
            this.FormComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.FormComboBox.Name = "FormComboBox";
            this.FormComboBox.Size = new System.Drawing.Size(180, 26);
            this.FormComboBox.TabIndex = 7;
            // 
            // AgeComboBox
            // 
            this.AgeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AgeComboBox.FormattingEnabled = true;
            this.AgeComboBox.Location = new System.Drawing.Point(34, 188);
            this.AgeComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.AgeComboBox.Name = "AgeComboBox";
            this.AgeComboBox.Size = new System.Drawing.Size(180, 26);
            this.AgeComboBox.TabIndex = 6;
            // 
            // FormIdBox
            // 
            this.FormIdBox.AutoSize = true;
            this.FormIdBox.Location = new System.Drawing.Point(30, 235);
            this.FormIdBox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.FormIdBox.Name = "FormIdBox";
            this.FormIdBox.Size = new System.Drawing.Size(143, 18);
            this.FormIdBox.TabIndex = 5;
            this.FormIdBox.Text = "Форма проведения";
            // 
            // AgeIdBox
            // 
            this.AgeIdBox.AutoSize = true;
            this.AgeIdBox.Location = new System.Drawing.Point(30, 166);
            this.AgeIdBox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AgeIdBox.Name = "AgeIdBox";
            this.AgeIdBox.Size = new System.Drawing.Size(182, 18);
            this.AgeIdBox.TabIndex = 4;
            this.AgeIdBox.Text = "Возрастное ограничение";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Тип";
            // 
            // TypeIdBox
            // 
            this.TypeIdBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TypeIdBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.TypeIdBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TypeIdBox.FormattingEnabled = true;
            this.TypeIdBox.Location = new System.Drawing.Point(34, 120);
            this.TypeIdBox.Margin = new System.Windows.Forms.Padding(4);
            this.TypeIdBox.Name = "TypeIdBox";
            this.TypeIdBox.Size = new System.Drawing.Size(180, 26);
            this.TypeIdBox.TabIndex = 2;
            // 
            // EventName
            // 
            this.EventName.Location = new System.Drawing.Point(34, 51);
            this.EventName.Margin = new System.Windows.Forms.Padding(4);
            this.EventName.Name = "EventName";
            this.EventName.Size = new System.Drawing.Size(148, 24);
            this.EventName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Название";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.EventDesc2);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.EventLink2);
            this.tabPage4.Controls.Add(this.FormComboBox2);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.AgeComboBox2);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.TypeIdBox2);
            this.tabPage4.Controls.Add(this.EventName2);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.SaveButton2);
            this.tabPage4.Controls.Add(this.DeleteButton1);
            this.tabPage4.Controls.Add(this.dataGridView1);
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(1176, 535);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Редактировать и удалить";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // EventDesc2
            // 
            this.EventDesc2.Location = new System.Drawing.Point(627, 421);
            this.EventDesc2.Margin = new System.Windows.Forms.Padding(4);
            this.EventDesc2.Name = "EventDesc2";
            this.EventDesc2.Size = new System.Drawing.Size(361, 93);
            this.EventDesc2.TabIndex = 18;
            this.EventDesc2.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(622, 399);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 18);
            this.label8.TabIndex = 17;
            this.label8.Text = "Описание";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(414, 397);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(151, 18);
            this.label9.TabIndex = 16;
            this.label9.Text = "Ссылка на источник";
            // 
            // EventLink2
            // 
            this.EventLink2.Location = new System.Drawing.Point(418, 420);
            this.EventLink2.Margin = new System.Windows.Forms.Padding(4);
            this.EventLink2.Name = "EventLink2";
            this.EventLink2.Size = new System.Drawing.Size(184, 24);
            this.EventLink2.TabIndex = 15;
            // 
            // FormComboBox2
            // 
            this.FormComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FormComboBox2.FormattingEnabled = true;
            this.FormComboBox2.Location = new System.Drawing.Point(202, 486);
            this.FormComboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.FormComboBox2.Name = "FormComboBox2";
            this.FormComboBox2.Size = new System.Drawing.Size(180, 26);
            this.FormComboBox2.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(198, 462);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(143, 18);
            this.label10.TabIndex = 13;
            this.label10.Text = "Форма проведения";
            // 
            // AgeComboBox2
            // 
            this.AgeComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AgeComboBox2.FormattingEnabled = true;
            this.AgeComboBox2.Location = new System.Drawing.Point(202, 420);
            this.AgeComboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.AgeComboBox2.Name = "AgeComboBox2";
            this.AgeComboBox2.Size = new System.Drawing.Size(180, 26);
            this.AgeComboBox2.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(198, 397);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 18);
            this.label3.TabIndex = 11;
            this.label3.Text = "Возрастное ограничение";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 464);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 18);
            this.label4.TabIndex = 10;
            this.label4.Text = "Тип";
            // 
            // TypeIdBox2
            // 
            this.TypeIdBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TypeIdBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.TypeIdBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TypeIdBox2.FormattingEnabled = true;
            this.TypeIdBox2.Location = new System.Drawing.Point(9, 486);
            this.TypeIdBox2.Margin = new System.Windows.Forms.Padding(4);
            this.TypeIdBox2.Name = "TypeIdBox2";
            this.TypeIdBox2.Size = new System.Drawing.Size(180, 26);
            this.TypeIdBox2.TabIndex = 9;
            // 
            // EventName2
            // 
            this.EventName2.Location = new System.Drawing.Point(9, 421);
            this.EventName2.Margin = new System.Windows.Forms.Padding(4);
            this.EventName2.Name = "EventName2";
            this.EventName2.Size = new System.Drawing.Size(180, 24);
            this.EventName2.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 399);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "Название";
            // 
            // SaveButton2
            // 
            this.SaveButton2.Location = new System.Drawing.Point(249, 328);
            this.SaveButton2.Margin = new System.Windows.Forms.Padding(4);
            this.SaveButton2.Name = "SaveButton2";
            this.SaveButton2.Size = new System.Drawing.Size(231, 53);
            this.SaveButton2.TabIndex = 2;
            this.SaveButton2.Text = "Сохранить";
            this.SaveButton2.UseVisualStyleBackColor = true;
            this.SaveButton2.Click += new System.EventHandler(this.SaveButton2_Click);
            // 
            // DeleteButton1
            // 
            this.DeleteButton1.Location = new System.Drawing.Point(9, 328);
            this.DeleteButton1.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteButton1.Name = "DeleteButton1";
            this.DeleteButton1.Size = new System.Drawing.Size(231, 53);
            this.DeleteButton1.TabIndex = 1;
            this.DeleteButton1.Text = "Удалить";
            this.DeleteButton1.UseVisualStyleBackColor = true;
            this.DeleteButton1.Click += new System.EventHandler(this.DeleteButton1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(4, 4);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1168, 316);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.StagesControl);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1192, 575);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Этапы";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // StagesControl
            // 
            this.StagesControl.Controls.Add(this.tabPage5);
            this.StagesControl.Controls.Add(this.tabPage6);
            this.StagesControl.Dock = System.Windows.Forms.DockStyle.Top;
            this.StagesControl.Location = new System.Drawing.Point(4, 4);
            this.StagesControl.Margin = new System.Windows.Forms.Padding(4);
            this.StagesControl.Name = "StagesControl";
            this.StagesControl.SelectedIndex = 0;
            this.StagesControl.Size = new System.Drawing.Size(1184, 566);
            this.StagesControl.TabIndex = 0;
            this.StagesControl.SelectedIndexChanged += new System.EventHandler(this.StagesControl_SelectedIndexChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.HouseText1);
            this.tabPage5.Controls.Add(this.label41);
            this.tabPage5.Controls.Add(this.StageName1);
            this.tabPage5.Controls.Add(this.EventsComboBox1);
            this.tabPage5.Controls.Add(this.SaveButtonStages1);
            this.tabPage5.Controls.Add(this.StageDesc1);
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.CostNumeric1);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.dateTimeFinish1);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.AdressComboBox1);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.StageNumeric1);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.dateTimeStart1);
            this.tabPage5.Location = new System.Drawing.Point(4, 27);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage5.Size = new System.Drawing.Size(1176, 535);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Добавить";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // StageName1
            // 
            this.StageName1.Location = new System.Drawing.Point(9, 174);
            this.StageName1.Margin = new System.Windows.Forms.Padding(4);
            this.StageName1.Name = "StageName1";
            this.StageName1.Size = new System.Drawing.Size(178, 24);
            this.StageName1.TabIndex = 22;
            // 
            // EventsComboBox1
            // 
            this.EventsComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.EventsComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.EventsComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EventsComboBox1.FormattingEnabled = true;
            this.EventsComboBox1.Location = new System.Drawing.Point(9, 107);
            this.EventsComboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.EventsComboBox1.Name = "EventsComboBox1";
            this.EventsComboBox1.Size = new System.Drawing.Size(180, 26);
            this.EventsComboBox1.TabIndex = 21;
            // 
            // SaveButtonStages1
            // 
            this.SaveButtonStages1.Location = new System.Drawing.Point(394, 246);
            this.SaveButtonStages1.Margin = new System.Windows.Forms.Padding(4);
            this.SaveButtonStages1.Name = "SaveButtonStages1";
            this.SaveButtonStages1.Size = new System.Drawing.Size(266, 73);
            this.SaveButtonStages1.TabIndex = 20;
            this.SaveButtonStages1.Text = "Сохранить";
            this.SaveButtonStages1.UseVisualStyleBackColor = true;
            this.SaveButtonStages1.Click += new System.EventHandler(this.SaveButtonStages1_Click);
            this.SaveButtonStages1.MouseLeave += new System.EventHandler(this.SaveButtonStages1_MouseLeave);
            // 
            // StageDesc1
            // 
            this.StageDesc1.Location = new System.Drawing.Point(394, 107);
            this.StageDesc1.Margin = new System.Windows.Forms.Padding(4);
            this.StageDesc1.Name = "StageDesc1";
            this.StageDesc1.Size = new System.Drawing.Size(392, 131);
            this.StageDesc1.TabIndex = 17;
            this.StageDesc1.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(394, 84);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(119, 18);
            this.label18.TabIndex = 16;
            this.label18.Text = "Описание этапа";
            // 
            // CostNumeric1
            // 
            this.CostNumeric1.Location = new System.Drawing.Point(394, 40);
            this.CostNumeric1.Margin = new System.Windows.Forms.Padding(4);
            this.CostNumeric1.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.CostNumeric1.Name = "CostNumeric1";
            this.CostNumeric1.Size = new System.Drawing.Size(180, 24);
            this.CostNumeric1.TabIndex = 15;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(394, 18);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(144, 18);
            this.label17.TabIndex = 14;
            this.label17.Text = "Стоимость участия";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 352);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(147, 18);
            this.label16.TabIndex = 13;
            this.label16.Text = "Дата и время конца";
            // 
            // dateTimeFinish1
            // 
            this.dateTimeFinish1.CustomFormat = "d-MM-yyyy HH:mm";
            this.dateTimeFinish1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeFinish1.Location = new System.Drawing.Point(9, 374);
            this.dateTimeFinish1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeFinish1.Name = "dateTimeFinish1";
            this.dateTimeFinish1.Size = new System.Drawing.Size(298, 24);
            this.dateTimeFinish1.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 288);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(155, 18);
            this.label15.TabIndex = 11;
            this.label15.Text = "Дата и время начала";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 217);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 18);
            this.label14.TabIndex = 10;
            this.label14.Text = "Улица";
            // 
            // AdressComboBox1
            // 
            this.AdressComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.AdressComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.AdressComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AdressComboBox1.FormattingEnabled = true;
            this.AdressComboBox1.Location = new System.Drawing.Point(9, 240);
            this.AdressComboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.AdressComboBox1.Name = "AdressComboBox1";
            this.AdressComboBox1.Size = new System.Drawing.Size(180, 26);
            this.AdressComboBox1.TabIndex = 9;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 152);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(118, 18);
            this.label13.TabIndex = 7;
            this.label13.Text = "Название этапа";
            // 
            // StageNumeric1
            // 
            this.StageNumeric1.Location = new System.Drawing.Point(9, 40);
            this.StageNumeric1.Margin = new System.Windows.Forms.Padding(4);
            this.StageNumeric1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.StageNumeric1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StageNumeric1.Name = "StageNumeric1";
            this.StageNumeric1.Size = new System.Drawing.Size(180, 24);
            this.StageNumeric1.TabIndex = 5;
            this.StageNumeric1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 84);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 18);
            this.label12.TabIndex = 4;
            this.label12.Text = "Мероприятие";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 18);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 18);
            this.label11.TabIndex = 3;
            this.label11.Text = "Номер этапа";
            // 
            // dateTimeStart1
            // 
            this.dateTimeStart1.CustomFormat = "d-MM-yyyy HH:mm";
            this.dateTimeStart1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeStart1.Location = new System.Drawing.Point(9, 310);
            this.dateTimeStart1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeStart1.Name = "dateTimeStart1";
            this.dateTimeStart1.Size = new System.Drawing.Size(298, 24);
            this.dateTimeStart1.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.HouseText2);
            this.tabPage6.Controls.Add(this.label42);
            this.tabPage6.Controls.Add(this.dataGridView2);
            this.tabPage6.Controls.Add(this.SaveButtonStages2);
            this.tabPage6.Controls.Add(this.DeleteButtonStages);
            this.tabPage6.Controls.Add(this.label28);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.StageDesc2);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.CostNumeric2);
            this.tabPage6.Controls.Add(this.label26);
            this.tabPage6.Controls.Add(this.StageName2);
            this.tabPage6.Controls.Add(this.EventsComboBox2);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.AdressComboBox2);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.StageNumeric2);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Controls.Add(this.label23);
            this.tabPage6.Controls.Add(this.dateTimeFinish2);
            this.tabPage6.Controls.Add(this.dateTimeStart2);
            this.tabPage6.Location = new System.Drawing.Point(4, 27);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(1176, 535);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Редактировать и у далить";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView2.Location = new System.Drawing.Point(4, 4);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(1168, 324);
            this.dataGridView2.TabIndex = 41;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // SaveButtonStages2
            // 
            this.SaveButtonStages2.Location = new System.Drawing.Point(249, 336);
            this.SaveButtonStages2.Margin = new System.Windows.Forms.Padding(4);
            this.SaveButtonStages2.Name = "SaveButtonStages2";
            this.SaveButtonStages2.Size = new System.Drawing.Size(231, 53);
            this.SaveButtonStages2.TabIndex = 40;
            this.SaveButtonStages2.Text = "Сохранить";
            this.SaveButtonStages2.UseVisualStyleBackColor = true;
            this.SaveButtonStages2.Click += new System.EventHandler(this.SaveButtonStages2_Click);
            // 
            // DeleteButtonStages
            // 
            this.DeleteButtonStages.Location = new System.Drawing.Point(9, 336);
            this.DeleteButtonStages.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteButtonStages.Name = "DeleteButtonStages";
            this.DeleteButtonStages.Size = new System.Drawing.Size(231, 53);
            this.DeleteButtonStages.TabIndex = 39;
            this.DeleteButtonStages.Text = "Удалить";
            this.DeleteButtonStages.UseVisualStyleBackColor = true;
            this.DeleteButtonStages.Click += new System.EventHandler(this.DeleteButtonStages_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(509, 472);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(147, 18);
            this.label28.TabIndex = 38;
            this.label28.Text = "Дата и время конца";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(509, 408);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(155, 18);
            this.label27.TabIndex = 37;
            this.label27.Text = "Дата и время начала";
            // 
            // StageDesc2
            // 
            this.StageDesc2.Location = new System.Drawing.Point(950, 359);
            this.StageDesc2.Margin = new System.Windows.Forms.Padding(4);
            this.StageDesc2.Name = "StageDesc2";
            this.StageDesc2.Size = new System.Drawing.Size(206, 162);
            this.StageDesc2.TabIndex = 34;
            this.StageDesc2.Text = "";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(945, 336);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(119, 18);
            this.label25.TabIndex = 33;
            this.label25.Text = "Описание этапа";
            // 
            // CostNumeric2
            // 
            this.CostNumeric2.Location = new System.Drawing.Point(746, 428);
            this.CostNumeric2.Margin = new System.Windows.Forms.Padding(4);
            this.CostNumeric2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.CostNumeric2.Name = "CostNumeric2";
            this.CostNumeric2.Size = new System.Drawing.Size(180, 24);
            this.CostNumeric2.TabIndex = 32;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(746, 406);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(144, 18);
            this.label26.TabIndex = 31;
            this.label26.Text = "Стоимость участия";
            // 
            // StageName2
            // 
            this.StageName2.Location = new System.Drawing.Point(214, 428);
            this.StageName2.Margin = new System.Windows.Forms.Padding(4);
            this.StageName2.Name = "StageName2";
            this.StageName2.Size = new System.Drawing.Size(178, 24);
            this.StageName2.TabIndex = 30;
            // 
            // EventsComboBox2
            // 
            this.EventsComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.EventsComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.EventsComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EventsComboBox2.FormattingEnabled = true;
            this.EventsComboBox2.Location = new System.Drawing.Point(9, 493);
            this.EventsComboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.EventsComboBox2.Name = "EventsComboBox2";
            this.EventsComboBox2.Size = new System.Drawing.Size(180, 26);
            this.EventsComboBox2.TabIndex = 29;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(214, 471);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 18);
            this.label20.TabIndex = 28;
            this.label20.Text = "Улица";
            // 
            // AdressComboBox2
            // 
            this.AdressComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.AdressComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.AdressComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AdressComboBox2.FormattingEnabled = true;
            this.AdressComboBox2.Location = new System.Drawing.Point(214, 493);
            this.AdressComboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.AdressComboBox2.Name = "AdressComboBox2";
            this.AdressComboBox2.Size = new System.Drawing.Size(180, 26);
            this.AdressComboBox2.TabIndex = 27;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(214, 406);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(118, 18);
            this.label21.TabIndex = 26;
            this.label21.Text = "Название этапа";
            // 
            // StageNumeric2
            // 
            this.StageNumeric2.Location = new System.Drawing.Point(9, 426);
            this.StageNumeric2.Margin = new System.Windows.Forms.Padding(4);
            this.StageNumeric2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.StageNumeric2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StageNumeric2.Name = "StageNumeric2";
            this.StageNumeric2.Size = new System.Drawing.Size(180, 24);
            this.StageNumeric2.TabIndex = 25;
            this.StageNumeric2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(9, 471);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(101, 18);
            this.label22.TabIndex = 24;
            this.label22.Text = "Мероприятие";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 404);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(98, 18);
            this.label23.TabIndex = 23;
            this.label23.Text = "Номер этапа";
            // 
            // dateTimeFinish2
            // 
            this.dateTimeFinish2.CustomFormat = "d.MM.yyyy HH:mm";
            this.dateTimeFinish2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeFinish2.Location = new System.Drawing.Point(512, 494);
            this.dateTimeFinish2.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeFinish2.Name = "dateTimeFinish2";
            this.dateTimeFinish2.Size = new System.Drawing.Size(204, 24);
            this.dateTimeFinish2.TabIndex = 4;
            // 
            // dateTimeStart2
            // 
            this.dateTimeStart2.CustomFormat = "d.MM.yyyy HH:mm";
            this.dateTimeStart2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeStart2.Location = new System.Drawing.Point(512, 430);
            this.dateTimeStart2.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeStart2.Name = "dateTimeStart2";
            this.dateTimeStart2.Size = new System.Drawing.Size(204, 24);
            this.dateTimeStart2.TabIndex = 3;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.label43);
            this.tabPage7.Controls.Add(this.ManagerName1);
            this.tabPage7.Controls.Add(this.label33);
            this.tabPage7.Controls.Add(this.label32);
            this.tabPage7.Controls.Add(this.label31);
            this.tabPage7.Controls.Add(this.label30);
            this.tabPage7.Controls.Add(this.label29);
            this.tabPage7.Controls.Add(this.ManagerDesc1);
            this.tabPage7.Controls.Add(this.ManagerLink1);
            this.tabPage7.Controls.Add(this.ManagerTypeCombo1);
            this.tabPage7.Controls.Add(this.ManagerOtch1);
            this.tabPage7.Controls.Add(this.ManagerSurname1);
            this.tabPage7.Controls.Add(this.UpdateButtonManager1);
            this.tabPage7.Controls.Add(this.SaveButtonManager1);
            this.tabPage7.Controls.Add(this.DeleteButtonManager1);
            this.tabPage7.Controls.Add(this.dataGridView3);
            this.tabPage7.Location = new System.Drawing.Point(4, 27);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage7.Size = new System.Drawing.Size(1192, 575);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Организаторы";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(672, 395);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(80, 18);
            this.label33.TabIndex = 52;
            this.label33.Text = "Описание ";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(427, 466);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(67, 18);
            this.label32.TabIndex = 51;
            this.label32.Text = "Ссылка ";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(432, 397);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(132, 18);
            this.label31.TabIndex = 50;
            this.label31.Text = "Тип организатора";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(9, 468);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(75, 18);
            this.label30.TabIndex = 49;
            this.label30.Text = "Отчество";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(12, 399);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(172, 18);
            this.label29.TabIndex = 48;
            this.label29.Text = "Фамилия организатора";
            // 
            // ManagerDesc1
            // 
            this.ManagerDesc1.Location = new System.Drawing.Point(676, 418);
            this.ManagerDesc1.Margin = new System.Windows.Forms.Padding(4);
            this.ManagerDesc1.Name = "ManagerDesc1";
            this.ManagerDesc1.Size = new System.Drawing.Size(456, 109);
            this.ManagerDesc1.TabIndex = 47;
            this.ManagerDesc1.Text = "";
            // 
            // ManagerLink1
            // 
            this.ManagerLink1.Location = new System.Drawing.Point(432, 488);
            this.ManagerLink1.Margin = new System.Windows.Forms.Padding(4);
            this.ManagerLink1.Name = "ManagerLink1";
            this.ManagerLink1.Size = new System.Drawing.Size(205, 24);
            this.ManagerLink1.TabIndex = 46;
            // 
            // ManagerTypeCombo1
            // 
            this.ManagerTypeCombo1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ManagerTypeCombo1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ManagerTypeCombo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ManagerTypeCombo1.FormattingEnabled = true;
            this.ManagerTypeCombo1.Location = new System.Drawing.Point(432, 419);
            this.ManagerTypeCombo1.Margin = new System.Windows.Forms.Padding(4);
            this.ManagerTypeCombo1.Name = "ManagerTypeCombo1";
            this.ManagerTypeCombo1.Size = new System.Drawing.Size(205, 26);
            this.ManagerTypeCombo1.TabIndex = 45;
            // 
            // ManagerOtch1
            // 
            this.ManagerOtch1.Location = new System.Drawing.Point(9, 490);
            this.ManagerOtch1.Margin = new System.Windows.Forms.Padding(4);
            this.ManagerOtch1.Name = "ManagerOtch1";
            this.ManagerOtch1.Size = new System.Drawing.Size(205, 24);
            this.ManagerOtch1.TabIndex = 44;
            // 
            // ManagerSurname1
            // 
            this.ManagerSurname1.Location = new System.Drawing.Point(12, 421);
            this.ManagerSurname1.Margin = new System.Windows.Forms.Padding(4);
            this.ManagerSurname1.Name = "ManagerSurname1";
            this.ManagerSurname1.Size = new System.Drawing.Size(202, 24);
            this.ManagerSurname1.TabIndex = 43;
            // 
            // UpdateButtonManager1
            // 
            this.UpdateButtonManager1.Location = new System.Drawing.Point(492, 327);
            this.UpdateButtonManager1.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateButtonManager1.Name = "UpdateButtonManager1";
            this.UpdateButtonManager1.Size = new System.Drawing.Size(231, 53);
            this.UpdateButtonManager1.TabIndex = 42;
            this.UpdateButtonManager1.Text = "Обновить";
            this.UpdateButtonManager1.UseVisualStyleBackColor = true;
            this.UpdateButtonManager1.Click += new System.EventHandler(this.UpdateButtonManager2_Click);
            // 
            // SaveButtonManager1
            // 
            this.SaveButtonManager1.Location = new System.Drawing.Point(12, 327);
            this.SaveButtonManager1.Margin = new System.Windows.Forms.Padding(4);
            this.SaveButtonManager1.Name = "SaveButtonManager1";
            this.SaveButtonManager1.Size = new System.Drawing.Size(231, 53);
            this.SaveButtonManager1.TabIndex = 41;
            this.SaveButtonManager1.Text = "Сохранить";
            this.SaveButtonManager1.UseVisualStyleBackColor = true;
            this.SaveButtonManager1.Click += new System.EventHandler(this.SaveButtonManager1_Click);
            this.SaveButtonManager1.MouseLeave += new System.EventHandler(this.SaveButtonManager1_MouseLeave);
            // 
            // DeleteButtonManager1
            // 
            this.DeleteButtonManager1.Location = new System.Drawing.Point(252, 327);
            this.DeleteButtonManager1.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteButtonManager1.Name = "DeleteButtonManager1";
            this.DeleteButtonManager1.Size = new System.Drawing.Size(231, 53);
            this.DeleteButtonManager1.TabIndex = 40;
            this.DeleteButtonManager1.Text = "Удалить";
            this.DeleteButtonManager1.UseVisualStyleBackColor = true;
            this.DeleteButtonManager1.Click += new System.EventHandler(this.DeleteButtonManager1_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(9, 8);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.Size = new System.Drawing.Size(1170, 310);
            this.dataGridView3.TabIndex = 0;
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label19);
            this.tabPage8.Controls.Add(this.MemberName1);
            this.tabPage8.Controls.Add(this.label34);
            this.tabPage8.Controls.Add(this.label35);
            this.tabPage8.Controls.Add(this.label36);
            this.tabPage8.Controls.Add(this.label37);
            this.tabPage8.Controls.Add(this.label38);
            this.tabPage8.Controls.Add(this.MemberDesc1);
            this.tabPage8.Controls.Add(this.MemberLink1);
            this.tabPage8.Controls.Add(this.MemberTypeCombo1);
            this.tabPage8.Controls.Add(this.MemberOtch1);
            this.tabPage8.Controls.Add(this.MemberSurname1);
            this.tabPage8.Controls.Add(this.UpdateButtonMember1);
            this.tabPage8.Controls.Add(this.DeleteButtonMember1);
            this.tabPage8.Controls.Add(this.SaveButtonMember1);
            this.tabPage8.Controls.Add(this.dataGridView4);
            this.tabPage8.Location = new System.Drawing.Point(4, 27);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage8.Size = new System.Drawing.Size(1192, 575);
            this.tabPage8.TabIndex = 3;
            this.tabPage8.Text = "Участники";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(719, 398);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(80, 18);
            this.label34.TabIndex = 62;
            this.label34.Text = "Описание ";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(474, 469);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(67, 18);
            this.label35.TabIndex = 61;
            this.label35.Text = "Ссылка ";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(479, 400);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(107, 18);
            this.label36.TabIndex = 60;
            this.label36.Text = "Тип участника";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(9, 468);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(75, 18);
            this.label37.TabIndex = 59;
            this.label37.Text = "Отчество";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(12, 399);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(147, 18);
            this.label38.TabIndex = 58;
            this.label38.Text = "Фамилия участника";
            // 
            // MemberDesc1
            // 
            this.MemberDesc1.Location = new System.Drawing.Point(723, 421);
            this.MemberDesc1.Margin = new System.Windows.Forms.Padding(4);
            this.MemberDesc1.Name = "MemberDesc1";
            this.MemberDesc1.Size = new System.Drawing.Size(456, 109);
            this.MemberDesc1.TabIndex = 57;
            this.MemberDesc1.Text = "";
            // 
            // MemberLink1
            // 
            this.MemberLink1.Location = new System.Drawing.Point(479, 491);
            this.MemberLink1.Margin = new System.Windows.Forms.Padding(4);
            this.MemberLink1.Name = "MemberLink1";
            this.MemberLink1.Size = new System.Drawing.Size(205, 24);
            this.MemberLink1.TabIndex = 56;
            // 
            // MemberTypeCombo1
            // 
            this.MemberTypeCombo1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.MemberTypeCombo1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.MemberTypeCombo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MemberTypeCombo1.FormattingEnabled = true;
            this.MemberTypeCombo1.Location = new System.Drawing.Point(479, 422);
            this.MemberTypeCombo1.Margin = new System.Windows.Forms.Padding(4);
            this.MemberTypeCombo1.Name = "MemberTypeCombo1";
            this.MemberTypeCombo1.Size = new System.Drawing.Size(205, 26);
            this.MemberTypeCombo1.TabIndex = 55;
            // 
            // MemberOtch1
            // 
            this.MemberOtch1.Location = new System.Drawing.Point(9, 490);
            this.MemberOtch1.Margin = new System.Windows.Forms.Padding(4);
            this.MemberOtch1.Name = "MemberOtch1";
            this.MemberOtch1.Size = new System.Drawing.Size(205, 24);
            this.MemberOtch1.TabIndex = 54;
            // 
            // MemberSurname1
            // 
            this.MemberSurname1.Location = new System.Drawing.Point(12, 421);
            this.MemberSurname1.Margin = new System.Windows.Forms.Padding(4);
            this.MemberSurname1.Name = "MemberSurname1";
            this.MemberSurname1.Size = new System.Drawing.Size(202, 24);
            this.MemberSurname1.TabIndex = 53;
            // 
            // UpdateButtonMember1
            // 
            this.UpdateButtonMember1.Location = new System.Drawing.Point(492, 327);
            this.UpdateButtonMember1.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateButtonMember1.Name = "UpdateButtonMember1";
            this.UpdateButtonMember1.Size = new System.Drawing.Size(231, 53);
            this.UpdateButtonMember1.TabIndex = 44;
            this.UpdateButtonMember1.Text = "Обновить";
            this.UpdateButtonMember1.UseVisualStyleBackColor = true;
            this.UpdateButtonMember1.Click += new System.EventHandler(this.UpdateButtonMember1_Click);
            // 
            // DeleteButtonMember1
            // 
            this.DeleteButtonMember1.Location = new System.Drawing.Point(252, 327);
            this.DeleteButtonMember1.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteButtonMember1.Name = "DeleteButtonMember1";
            this.DeleteButtonMember1.Size = new System.Drawing.Size(231, 53);
            this.DeleteButtonMember1.TabIndex = 43;
            this.DeleteButtonMember1.Text = "Удалить";
            this.DeleteButtonMember1.UseVisualStyleBackColor = true;
            this.DeleteButtonMember1.Click += new System.EventHandler(this.DeleteButtonMember1_Click);
            // 
            // SaveButtonMember1
            // 
            this.SaveButtonMember1.Location = new System.Drawing.Point(12, 327);
            this.SaveButtonMember1.Margin = new System.Windows.Forms.Padding(4);
            this.SaveButtonMember1.Name = "SaveButtonMember1";
            this.SaveButtonMember1.Size = new System.Drawing.Size(231, 53);
            this.SaveButtonMember1.TabIndex = 42;
            this.SaveButtonMember1.Text = "Сохранить";
            this.SaveButtonMember1.UseVisualStyleBackColor = true;
            this.SaveButtonMember1.Click += new System.EventHandler(this.SaveButtonMember1_Click);
            this.SaveButtonMember1.MouseLeave += new System.EventHandler(this.SaveButtonMember1_MouseLeave);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(9, 8);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4.Size = new System.Drawing.Size(1170, 310);
            this.dataGridView4.TabIndex = 1;
            this.dataGridView4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellClick);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.UpdateButtonList1);
            this.tabPage9.Controls.Add(this.DeleteButtonList1);
            this.tabPage9.Controls.Add(this.SaveButtonList1);
            this.tabPage9.Controls.Add(this.label40);
            this.tabPage9.Controls.Add(this.label39);
            this.tabPage9.Controls.Add(this.MemberListCombo1);
            this.tabPage9.Controls.Add(this.EventListCombo1);
            this.tabPage9.Controls.Add(this.dataGridView5);
            this.tabPage9.Location = new System.Drawing.Point(4, 27);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage9.Size = new System.Drawing.Size(1192, 575);
            this.tabPage9.TabIndex = 4;
            this.tabPage9.Text = "Список участников";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // UpdateButtonList1
            // 
            this.UpdateButtonList1.Location = new System.Drawing.Point(489, 305);
            this.UpdateButtonList1.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateButtonList1.Name = "UpdateButtonList1";
            this.UpdateButtonList1.Size = new System.Drawing.Size(231, 53);
            this.UpdateButtonList1.TabIndex = 63;
            this.UpdateButtonList1.Text = "Обновить";
            this.UpdateButtonList1.UseVisualStyleBackColor = true;
            this.UpdateButtonList1.Click += new System.EventHandler(this.UpdateButtonList1_Click);
            // 
            // DeleteButtonList1
            // 
            this.DeleteButtonList1.Location = new System.Drawing.Point(249, 305);
            this.DeleteButtonList1.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteButtonList1.Name = "DeleteButtonList1";
            this.DeleteButtonList1.Size = new System.Drawing.Size(231, 53);
            this.DeleteButtonList1.TabIndex = 62;
            this.DeleteButtonList1.Text = "Удалить";
            this.DeleteButtonList1.UseVisualStyleBackColor = true;
            this.DeleteButtonList1.Click += new System.EventHandler(this.DeleteButtonList1_Click);
            // 
            // SaveButtonList1
            // 
            this.SaveButtonList1.Location = new System.Drawing.Point(9, 305);
            this.SaveButtonList1.Margin = new System.Windows.Forms.Padding(4);
            this.SaveButtonList1.Name = "SaveButtonList1";
            this.SaveButtonList1.Size = new System.Drawing.Size(231, 53);
            this.SaveButtonList1.TabIndex = 61;
            this.SaveButtonList1.Text = "Сохранить";
            this.SaveButtonList1.UseVisualStyleBackColor = true;
            this.SaveButtonList1.Click += new System.EventHandler(this.SaveButtonList1_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(228, 381);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(73, 18);
            this.label40.TabIndex = 60;
            this.label40.Text = "Участник";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 381);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(101, 18);
            this.label39.TabIndex = 59;
            this.label39.Text = "Мероприятие";
            // 
            // MemberListCombo1
            // 
            this.MemberListCombo1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.MemberListCombo1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.MemberListCombo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MemberListCombo1.FormattingEnabled = true;
            this.MemberListCombo1.Location = new System.Drawing.Point(228, 403);
            this.MemberListCombo1.Margin = new System.Windows.Forms.Padding(4);
            this.MemberListCombo1.Name = "MemberListCombo1";
            this.MemberListCombo1.Size = new System.Drawing.Size(205, 26);
            this.MemberListCombo1.TabIndex = 57;
            // 
            // EventListCombo1
            // 
            this.EventListCombo1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.EventListCombo1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.EventListCombo1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EventListCombo1.FormattingEnabled = true;
            this.EventListCombo1.Location = new System.Drawing.Point(12, 403);
            this.EventListCombo1.Margin = new System.Windows.Forms.Padding(4);
            this.EventListCombo1.Name = "EventListCombo1";
            this.EventListCombo1.Size = new System.Drawing.Size(205, 26);
            this.EventListCombo1.TabIndex = 56;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.AllowUserToDeleteRows = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(12, 8);
            this.dataGridView5.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView5.Size = new System.Drawing.Size(1164, 288);
            this.dataGridView5.TabIndex = 0;
            this.dataGridView5.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellClick);
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.UpdateButtonListManager1);
            this.tabPage10.Controls.Add(this.DeleteButtonListMaanger1);
            this.tabPage10.Controls.Add(this.SaveButtonListManager1);
            this.tabPage10.Controls.Add(this.label44);
            this.tabPage10.Controls.Add(this.label45);
            this.tabPage10.Controls.Add(this.ManagerPartCombo2);
            this.tabPage10.Controls.Add(this.EventPartCombo2);
            this.tabPage10.Controls.Add(this.dataGridView6);
            this.tabPage10.Location = new System.Drawing.Point(4, 27);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1192, 575);
            this.tabPage10.TabIndex = 5;
            this.tabPage10.Text = "Список организаторов";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(197, 220);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(40, 18);
            this.label41.TabIndex = 24;
            this.label41.Text = "Дом";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(402, 472);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(40, 18);
            this.label42.TabIndex = 43;
            this.label42.Text = "Дом";
            // 
            // HouseText2
            // 
            this.HouseText2.Location = new System.Drawing.Point(402, 494);
            this.HouseText2.Margin = new System.Windows.Forms.Padding(4);
            this.HouseText2.Name = "HouseText2";
            this.HouseText2.Size = new System.Drawing.Size(102, 24);
            this.HouseText2.TabIndex = 44;
            // 
            // HouseText1
            // 
            this.HouseText1.Location = new System.Drawing.Point(200, 242);
            this.HouseText1.Margin = new System.Windows.Forms.Padding(4);
            this.HouseText1.Name = "HouseText1";
            this.HouseText1.Size = new System.Drawing.Size(107, 24);
            this.HouseText1.TabIndex = 25;
            // 
            // ManagerName1
            // 
            this.ManagerName1.Location = new System.Drawing.Point(222, 421);
            this.ManagerName1.Margin = new System.Windows.Forms.Padding(4);
            this.ManagerName1.Name = "ManagerName1";
            this.ManagerName1.Size = new System.Drawing.Size(202, 24);
            this.ManagerName1.TabIndex = 53;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(222, 399);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(38, 18);
            this.label43.TabIndex = 54;
            this.label43.Text = "Имя";
            // 
            // UpdateButtonListManager1
            // 
            this.UpdateButtonListManager1.Location = new System.Drawing.Point(484, 304);
            this.UpdateButtonListManager1.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateButtonListManager1.Name = "UpdateButtonListManager1";
            this.UpdateButtonListManager1.Size = new System.Drawing.Size(231, 53);
            this.UpdateButtonListManager1.TabIndex = 71;
            this.UpdateButtonListManager1.Text = "Обновить";
            this.UpdateButtonListManager1.UseVisualStyleBackColor = true;
            this.UpdateButtonListManager1.Click += new System.EventHandler(this.UpdateButtonListManager1_Click);
            // 
            // DeleteButtonListMaanger1
            // 
            this.DeleteButtonListMaanger1.Location = new System.Drawing.Point(244, 304);
            this.DeleteButtonListMaanger1.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteButtonListMaanger1.Name = "DeleteButtonListMaanger1";
            this.DeleteButtonListMaanger1.Size = new System.Drawing.Size(231, 53);
            this.DeleteButtonListMaanger1.TabIndex = 70;
            this.DeleteButtonListMaanger1.Text = "Удалить";
            this.DeleteButtonListMaanger1.UseVisualStyleBackColor = true;
            this.DeleteButtonListMaanger1.Click += new System.EventHandler(this.DeleteButtonListMaanger1_Click);
            // 
            // SaveButtonListManager1
            // 
            this.SaveButtonListManager1.Location = new System.Drawing.Point(4, 304);
            this.SaveButtonListManager1.Margin = new System.Windows.Forms.Padding(4);
            this.SaveButtonListManager1.Name = "SaveButtonListManager1";
            this.SaveButtonListManager1.Size = new System.Drawing.Size(231, 53);
            this.SaveButtonListManager1.TabIndex = 69;
            this.SaveButtonListManager1.Text = "Сохранить";
            this.SaveButtonListManager1.UseVisualStyleBackColor = true;
            this.SaveButtonListManager1.Click += new System.EventHandler(this.SaveButtonListManager1_Click);
            this.SaveButtonListManager1.MouseLeave += new System.EventHandler(this.SaveButtonListManager1_MouseLeave);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(223, 380);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(98, 18);
            this.label44.TabIndex = 68;
            this.label44.Text = "Организатор";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(7, 380);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(101, 18);
            this.label45.TabIndex = 67;
            this.label45.Text = "Мероприятие";
            // 
            // ManagerPartCombo2
            // 
            this.ManagerPartCombo2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ManagerPartCombo2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ManagerPartCombo2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ManagerPartCombo2.FormattingEnabled = true;
            this.ManagerPartCombo2.Location = new System.Drawing.Point(223, 402);
            this.ManagerPartCombo2.Margin = new System.Windows.Forms.Padding(4);
            this.ManagerPartCombo2.Name = "ManagerPartCombo2";
            this.ManagerPartCombo2.Size = new System.Drawing.Size(205, 26);
            this.ManagerPartCombo2.TabIndex = 66;
            // 
            // EventPartCombo2
            // 
            this.EventPartCombo2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.EventPartCombo2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.EventPartCombo2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EventPartCombo2.FormattingEnabled = true;
            this.EventPartCombo2.Location = new System.Drawing.Point(7, 402);
            this.EventPartCombo2.Margin = new System.Windows.Forms.Padding(4);
            this.EventPartCombo2.Name = "EventPartCombo2";
            this.EventPartCombo2.Size = new System.Drawing.Size(205, 26);
            this.EventPartCombo2.TabIndex = 65;
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.AllowUserToDeleteRows = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(7, 7);
            this.dataGridView6.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            this.dataGridView6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView6.Size = new System.Drawing.Size(1164, 288);
            this.dataGridView6.TabIndex = 64;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(222, 400);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 18);
            this.label19.TabIndex = 68;
            this.label19.Text = "Имя";
            // 
            // MemberName1
            // 
            this.MemberName1.Location = new System.Drawing.Point(222, 421);
            this.MemberName1.Margin = new System.Windows.Forms.Padding(4);
            this.MemberName1.Name = "MemberName1";
            this.MemberName1.Size = new System.Drawing.Size(202, 24);
            this.MemberName1.TabIndex = 67;
            // 
            // EditForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 623);
            this.Controls.Add(this.MainTables);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EditForm1";
            this.Text = "EditForm1";
            this.MainTables.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.EventsControl.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.StagesControl.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CostNumeric1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StageNumeric1)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CostNumeric2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StageNumeric2)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl MainTables;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl EventsControl;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabControl StagesControl;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DateTimePicker dateTimeStart1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button Savebutton1;
        private System.Windows.Forms.RichTextBox EventDesc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EventLink;
        private System.Windows.Forms.ComboBox FormComboBox;
        private System.Windows.Forms.ComboBox AgeComboBox;
        private System.Windows.Forms.Label FormIdBox;
        private System.Windows.Forms.Label AgeIdBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox TypeIdBox;
        private System.Windows.Forms.TextBox EventName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button SaveButton2;
        private System.Windows.Forms.Button DeleteButton1;
        private System.Windows.Forms.RichTextBox EventDesc2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox EventLink2;
        private System.Windows.Forms.ComboBox FormComboBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox AgeComboBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox TypeIdBox2;
        private System.Windows.Forms.TextBox EventName2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox StageDesc1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown CostNumeric1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dateTimeFinish1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox AdressComboBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown StageNumeric1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox StageName1;
        private System.Windows.Forms.ComboBox EventsComboBox1;
        private System.Windows.Forms.Button SaveButtonStages1;
        private System.Windows.Forms.DateTimePicker dateTimeStart2;
        private System.Windows.Forms.DateTimePicker dateTimeFinish2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button SaveButtonStages2;
        private System.Windows.Forms.Button DeleteButtonStages;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.RichTextBox StageDesc2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown CostNumeric2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox StageName2;
        private System.Windows.Forms.ComboBox EventsComboBox2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox AdressComboBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown StageNumeric2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Button UpdateButtonManager1;
        private System.Windows.Forms.Button SaveButtonManager1;
        private System.Windows.Forms.Button DeleteButtonManager1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox ManagerDesc1;
        private System.Windows.Forms.TextBox ManagerLink1;
        private System.Windows.Forms.ComboBox ManagerTypeCombo1;
        private System.Windows.Forms.TextBox ManagerOtch1;
        private System.Windows.Forms.TextBox ManagerSurname1;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.RichTextBox MemberDesc1;
        private System.Windows.Forms.TextBox MemberLink1;
        private System.Windows.Forms.ComboBox MemberTypeCombo1;
        private System.Windows.Forms.TextBox MemberOtch1;
        private System.Windows.Forms.TextBox MemberSurname1;
        private System.Windows.Forms.Button UpdateButtonMember1;
        private System.Windows.Forms.Button DeleteButtonMember1;
        private System.Windows.Forms.Button SaveButtonMember1;
        private System.Windows.Forms.Button UpdateButtonList1;
        private System.Windows.Forms.Button DeleteButtonList1;
        private System.Windows.Forms.Button SaveButtonList1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox MemberListCombo1;
        private System.Windows.Forms.ComboBox EventListCombo1;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox HouseText1;
        private System.Windows.Forms.TextBox HouseText2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox ManagerName1;
        private System.Windows.Forms.Button UpdateButtonListManager1;
        private System.Windows.Forms.Button DeleteButtonListMaanger1;
        private System.Windows.Forms.Button SaveButtonListManager1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox ManagerPartCombo2;
        private System.Windows.Forms.ComboBox EventPartCombo2;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox MemberName1;
    }
}