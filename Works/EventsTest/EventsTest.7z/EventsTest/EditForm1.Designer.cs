﻿
namespace EventsTest
{
    partial class EditForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.Savebutton1 = new System.Windows.Forms.Button();
            this.EventDesc = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.EventLink = new System.Windows.Forms.TextBox();
            this.FormComboBox = new System.Windows.Forms.ComboBox();
            this.AgeComboBox = new System.Windows.Forms.ComboBox();
            this.FormIdBox = new System.Windows.Forms.Label();
            this.AgeIdBox = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TypeIdBox = new System.Windows.Forms.ComboBox();
            this.EventName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.EventDesc2 = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.EventLink2 = new System.Windows.Forms.TextBox();
            this.FormComboBox2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.AgeComboBox2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TypeIdBox2 = new System.Windows.Forms.ComboBox();
            this.EventName2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.SaveButton2 = new System.Windows.Forms.Button();
            this.DeleteButton1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dateTimeStart1 = new System.Windows.Forms.DateTimePicker();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.StageNumeric1 = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.AdressComboBox1 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.dateTimeFinish1 = new System.Windows.Forms.DateTimePicker();
            this.CostNumeric1 = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.StageDesc1 = new System.Windows.Forms.RichTextBox();
            this.ManagerComboBox1 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.SaveButtonStages1 = new System.Windows.Forms.Button();
            this.EventsComboBox1 = new System.Windows.Forms.ComboBox();
            this.StageName = new System.Windows.Forms.TextBox();
            this.dateTimeStart2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeFinish2 = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StageNumeric1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CostNumeric1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 438);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 412);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Мероприятия";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(786, 409);
            this.tabControl2.TabIndex = 2;
            this.tabControl2.Click += new System.EventHandler(this.tabControl2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.Savebutton1);
            this.tabPage3.Controls.Add(this.EventDesc);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.EventLink);
            this.tabPage3.Controls.Add(this.FormComboBox);
            this.tabPage3.Controls.Add(this.AgeComboBox);
            this.tabPage3.Controls.Add(this.FormIdBox);
            this.tabPage3.Controls.Add(this.AgeIdBox);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.TypeIdBox);
            this.tabPage3.Controls.Add(this.EventName);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(778, 383);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Добавить";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // Savebutton1
            // 
            this.Savebutton1.Location = new System.Drawing.Point(317, 312);
            this.Savebutton1.Name = "Savebutton1";
            this.Savebutton1.Size = new System.Drawing.Size(137, 35);
            this.Savebutton1.TabIndex = 12;
            this.Savebutton1.Text = "Сохранить";
            this.Savebutton1.UseVisualStyleBackColor = true;
            this.Savebutton1.Click += new System.EventHandler(this.Savebutton1_Click);
            this.Savebutton1.MouseLeave += new System.EventHandler(this.Savebutton1_MouseLeave);
            // 
            // EventDesc
            // 
            this.EventDesc.Location = new System.Drawing.Point(23, 283);
            this.EventDesc.Name = "EventDesc";
            this.EventDesc.Size = new System.Drawing.Size(242, 96);
            this.EventDesc.TabIndex = 11;
            this.EventDesc.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 267);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Описание";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Ссылка на источник";
            // 
            // EventLink
            // 
            this.EventLink.Location = new System.Drawing.Point(23, 233);
            this.EventLink.Name = "EventLink";
            this.EventLink.Size = new System.Drawing.Size(100, 20);
            this.EventLink.TabIndex = 8;
            // 
            // FormComboBox
            // 
            this.FormComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FormComboBox.FormattingEnabled = true;
            this.FormComboBox.Location = new System.Drawing.Point(23, 186);
            this.FormComboBox.Name = "FormComboBox";
            this.FormComboBox.Size = new System.Drawing.Size(121, 21);
            this.FormComboBox.TabIndex = 7;
            // 
            // AgeComboBox
            // 
            this.AgeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AgeComboBox.FormattingEnabled = true;
            this.AgeComboBox.Location = new System.Drawing.Point(23, 136);
            this.AgeComboBox.Name = "AgeComboBox";
            this.AgeComboBox.Size = new System.Drawing.Size(121, 21);
            this.AgeComboBox.TabIndex = 6;
            // 
            // FormIdBox
            // 
            this.FormIdBox.AutoSize = true;
            this.FormIdBox.Location = new System.Drawing.Point(20, 170);
            this.FormIdBox.Name = "FormIdBox";
            this.FormIdBox.Size = new System.Drawing.Size(107, 13);
            this.FormIdBox.TabIndex = 5;
            this.FormIdBox.Text = "Форма проведения";
            // 
            // AgeIdBox
            // 
            this.AgeIdBox.AutoSize = true;
            this.AgeIdBox.Location = new System.Drawing.Point(20, 120);
            this.AgeIdBox.Name = "AgeIdBox";
            this.AgeIdBox.Size = new System.Drawing.Size(134, 13);
            this.AgeIdBox.TabIndex = 4;
            this.AgeIdBox.Text = "Возрастное ограничение";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Тип";
            // 
            // TypeIdBox
            // 
            this.TypeIdBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TypeIdBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.TypeIdBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TypeIdBox.FormattingEnabled = true;
            this.TypeIdBox.Location = new System.Drawing.Point(23, 87);
            this.TypeIdBox.Name = "TypeIdBox";
            this.TypeIdBox.Size = new System.Drawing.Size(121, 21);
            this.TypeIdBox.TabIndex = 2;
            // 
            // EventName
            // 
            this.EventName.Location = new System.Drawing.Point(23, 37);
            this.EventName.Name = "EventName";
            this.EventName.Size = new System.Drawing.Size(100, 20);
            this.EventName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Название";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.EventDesc2);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.EventLink2);
            this.tabPage4.Controls.Add(this.FormComboBox2);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.AgeComboBox2);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.TypeIdBox2);
            this.tabPage4.Controls.Add(this.EventName2);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.SaveButton2);
            this.tabPage4.Controls.Add(this.DeleteButton1);
            this.tabPage4.Controls.Add(this.dataGridView1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(778, 383);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Редактировать и удалить";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // EventDesc2
            // 
            this.EventDesc2.Location = new System.Drawing.Point(398, 268);
            this.EventDesc2.Name = "EventDesc2";
            this.EventDesc2.Size = new System.Drawing.Size(242, 68);
            this.EventDesc2.TabIndex = 18;
            this.EventDesc2.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(395, 252);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Описание";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(276, 251);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Ссылка на источник";
            // 
            // EventLink2
            // 
            this.EventLink2.Location = new System.Drawing.Point(279, 267);
            this.EventLink2.Name = "EventLink2";
            this.EventLink2.Size = new System.Drawing.Size(100, 20);
            this.EventLink2.TabIndex = 15;
            // 
            // FormComboBox2
            // 
            this.FormComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FormComboBox2.FormattingEnabled = true;
            this.FormComboBox2.Location = new System.Drawing.Point(135, 314);
            this.FormComboBox2.Name = "FormComboBox2";
            this.FormComboBox2.Size = new System.Drawing.Size(121, 21);
            this.FormComboBox2.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(132, 298);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Форма проведения";
            // 
            // AgeComboBox2
            // 
            this.AgeComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AgeComboBox2.FormattingEnabled = true;
            this.AgeComboBox2.Location = new System.Drawing.Point(135, 267);
            this.AgeComboBox2.Name = "AgeComboBox2";
            this.AgeComboBox2.Size = new System.Drawing.Size(121, 21);
            this.AgeComboBox2.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(132, 251);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Возрастное ограничение";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Тип";
            // 
            // TypeIdBox2
            // 
            this.TypeIdBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.TypeIdBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.TypeIdBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TypeIdBox2.FormattingEnabled = true;
            this.TypeIdBox2.Location = new System.Drawing.Point(6, 315);
            this.TypeIdBox2.Name = "TypeIdBox2";
            this.TypeIdBox2.Size = new System.Drawing.Size(121, 21);
            this.TypeIdBox2.TabIndex = 9;
            // 
            // EventName2
            // 
            this.EventName2.Location = new System.Drawing.Point(6, 268);
            this.EventName2.Name = "EventName2";
            this.EventName2.Size = new System.Drawing.Size(100, 20);
            this.EventName2.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 252);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Название";
            // 
            // SaveButton2
            // 
            this.SaveButton2.Location = new System.Drawing.Point(166, 192);
            this.SaveButton2.Name = "SaveButton2";
            this.SaveButton2.Size = new System.Drawing.Size(154, 38);
            this.SaveButton2.TabIndex = 2;
            this.SaveButton2.Text = "Сохранить";
            this.SaveButton2.UseVisualStyleBackColor = true;
            this.SaveButton2.Click += new System.EventHandler(this.SaveButton2_Click);
            // 
            // DeleteButton1
            // 
            this.DeleteButton1.Location = new System.Drawing.Point(6, 192);
            this.DeleteButton1.Name = "DeleteButton1";
            this.DeleteButton1.Size = new System.Drawing.Size(154, 38);
            this.DeleteButton1.TabIndex = 1;
            this.DeleteButton1.Text = "Удалить";
            this.DeleteButton1.UseVisualStyleBackColor = true;
            this.DeleteButton1.Click += new System.EventHandler(this.DeleteButton1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(772, 183);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 412);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Этапы";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl3.Location = new System.Drawing.Point(3, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(786, 409);
            this.tabControl3.TabIndex = 0;
            this.tabControl3.SelectedIndexChanged += new System.EventHandler(this.tabControl3_SelectedIndexChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.StageName);
            this.tabPage5.Controls.Add(this.EventsComboBox1);
            this.tabPage5.Controls.Add(this.SaveButtonStages1);
            this.tabPage5.Controls.Add(this.ManagerComboBox1);
            this.tabPage5.Controls.Add(this.label19);
            this.tabPage5.Controls.Add(this.StageDesc1);
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.CostNumeric1);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.dateTimeFinish1);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.AdressComboBox1);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.StageNumeric1);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.dateTimeStart1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(778, 383);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Добавить";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dateTimeStart1
            // 
            this.dateTimeStart1.CustomFormat = "d.MM.yyyy HH:m";
            this.dateTimeStart1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeStart1.Location = new System.Drawing.Point(6, 224);
            this.dateTimeStart1.Name = "dateTimeStart1";
            this.dateTimeStart1.Size = new System.Drawing.Size(200, 20);
            this.dateTimeStart1.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dataGridView2);
            this.tabPage6.Controls.Add(this.button1);
            this.tabPage6.Controls.Add(this.button2);
            this.tabPage6.Controls.Add(this.label28);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.comboBox3);
            this.tabPage6.Controls.Add(this.label24);
            this.tabPage6.Controls.Add(this.richTextBox1);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.numericUpDown2);
            this.tabPage6.Controls.Add(this.label26);
            this.tabPage6.Controls.Add(this.textBox1);
            this.tabPage6.Controls.Add(this.comboBox1);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.comboBox2);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.numericUpDown1);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Controls.Add(this.label23);
            this.tabPage6.Controls.Add(this.dateTimeFinish2);
            this.tabPage6.Controls.Add(this.dateTimeStart2);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(778, 383);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Редактировать и у далить";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Номер этапа";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Мероприятие";
            // 
            // StageNumeric1
            // 
            this.StageNumeric1.Location = new System.Drawing.Point(6, 29);
            this.StageNumeric1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.StageNumeric1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.StageNumeric1.Name = "StageNumeric1";
            this.StageNumeric1.Size = new System.Drawing.Size(120, 20);
            this.StageNumeric1.TabIndex = 5;
            this.StageNumeric1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 110);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "Название этапа";
            // 
            // AdressComboBox1
            // 
            this.AdressComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.AdressComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.AdressComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AdressComboBox1.FormattingEnabled = true;
            this.AdressComboBox1.Location = new System.Drawing.Point(6, 173);
            this.AdressComboBox1.Name = "AdressComboBox1";
            this.AdressComboBox1.Size = new System.Drawing.Size(121, 21);
            this.AdressComboBox1.TabIndex = 9;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 157);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "Адрес проведения";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 208);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "Дата и время начала";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 254);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Дата и время конца";
            // 
            // dateTimeFinish1
            // 
            this.dateTimeFinish1.CustomFormat = "d.MM.yyyy HH:m";
            this.dateTimeFinish1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeFinish1.Location = new System.Drawing.Point(6, 270);
            this.dateTimeFinish1.Name = "dateTimeFinish1";
            this.dateTimeFinish1.Size = new System.Drawing.Size(200, 20);
            this.dateTimeFinish1.TabIndex = 12;
            // 
            // CostNumeric1
            // 
            this.CostNumeric1.Location = new System.Drawing.Point(263, 29);
            this.CostNumeric1.Name = "CostNumeric1";
            this.CostNumeric1.Size = new System.Drawing.Size(120, 20);
            this.CostNumeric1.TabIndex = 15;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(263, 13);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(104, 13);
            this.label17.TabIndex = 14;
            this.label17.Text = "Стоимость участия";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(263, 61);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(89, 13);
            this.label18.TabIndex = 16;
            this.label18.Text = "Описание этапа";
            // 
            // StageDesc1
            // 
            this.StageDesc1.Location = new System.Drawing.Point(263, 77);
            this.StageDesc1.Name = "StageDesc1";
            this.StageDesc1.Size = new System.Drawing.Size(263, 96);
            this.StageDesc1.TabIndex = 17;
            this.StageDesc1.Text = "";
            // 
            // ManagerComboBox1
            // 
            this.ManagerComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.ManagerComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ManagerComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ManagerComboBox1.FormattingEnabled = true;
            this.ManagerComboBox1.Location = new System.Drawing.Point(262, 223);
            this.ManagerComboBox1.Name = "ManagerComboBox1";
            this.ManagerComboBox1.Size = new System.Drawing.Size(121, 21);
            this.ManagerComboBox1.TabIndex = 19;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(262, 207);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 13);
            this.label19.TabIndex = 18;
            this.label19.Text = "Организатор";
            // 
            // SaveButtonStages1
            // 
            this.SaveButtonStages1.Location = new System.Drawing.Point(262, 265);
            this.SaveButtonStages1.Name = "SaveButtonStages1";
            this.SaveButtonStages1.Size = new System.Drawing.Size(137, 35);
            this.SaveButtonStages1.TabIndex = 20;
            this.SaveButtonStages1.Text = "Сохранить";
            this.SaveButtonStages1.UseVisualStyleBackColor = true;
            this.SaveButtonStages1.Click += new System.EventHandler(this.SaveButtonStages1_Click);
            // 
            // EventsComboBox1
            // 
            this.EventsComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.EventsComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.EventsComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EventsComboBox1.FormattingEnabled = true;
            this.EventsComboBox1.Location = new System.Drawing.Point(6, 77);
            this.EventsComboBox1.Name = "EventsComboBox1";
            this.EventsComboBox1.Size = new System.Drawing.Size(121, 21);
            this.EventsComboBox1.TabIndex = 21;
            // 
            // StageName
            // 
            this.StageName.Location = new System.Drawing.Point(6, 126);
            this.StageName.Name = "StageName";
            this.StageName.Size = new System.Drawing.Size(120, 20);
            this.StageName.TabIndex = 22;
            // 
            // dateTimeStart2
            // 
            this.dateTimeStart2.CustomFormat = "d.MM.yyyy HH:mm";
            this.dateTimeStart2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeStart2.Location = new System.Drawing.Point(279, 309);
            this.dateTimeStart2.Name = "dateTimeStart2";
            this.dateTimeStart2.Size = new System.Drawing.Size(200, 20);
            this.dateTimeStart2.TabIndex = 3;
            // 
            // dateTimeFinish2
            // 
            this.dateTimeFinish2.CustomFormat = "d.MM.yyyy HH:mm";
            this.dateTimeFinish2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimeFinish2.Location = new System.Drawing.Point(279, 357);
            this.dateTimeFinish2.Name = "dateTimeFinish2";
            this.dateTimeFinish2.Size = new System.Drawing.Size(200, 20);
            this.dateTimeFinish2.TabIndex = 4;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(143, 309);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 30;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(6, 356);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 29;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(143, 340);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(101, 13);
            this.label20.TabIndex = 28;
            this.label20.Text = "Адрес проведения";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(143, 356);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 27;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(143, 293);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 13);
            this.label21.TabIndex = 26;
            this.label21.Text = "Название этапа";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(6, 308);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 25;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 340);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 13);
            this.label22.TabIndex = 24;
            this.label22.Text = "Мероприятие";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 292);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(73, 13);
            this.label23.TabIndex = 23;
            this.label23.Text = "Номер этапа";
            // 
            // comboBox3
            // 
            this.comboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(497, 356);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 36;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(497, 340);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(73, 13);
            this.label24.TabIndex = 35;
            this.label24.Text = "Организатор";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(633, 259);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(139, 118);
            this.richTextBox1.TabIndex = 34;
            this.richTextBox1.Text = "";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(630, 243);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(89, 13);
            this.label25.TabIndex = 33;
            this.label25.Text = "Описание этапа";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(497, 309);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown2.TabIndex = 32;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(497, 293);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(104, 13);
            this.label26.TabIndex = 31;
            this.label26.Text = "Стоимость участия";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(279, 295);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(115, 13);
            this.label27.TabIndex = 37;
            this.label27.Text = "Дата и время начала";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(279, 341);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(110, 13);
            this.label28.TabIndex = 38;
            this.label28.Text = "Дата и время конца";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(166, 243);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 38);
            this.button1.TabIndex = 40;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 243);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 38);
            this.button2.TabIndex = 39;
            this.button2.Text = "Удалить";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(772, 234);
            this.dataGridView2.TabIndex = 41;
            // 
            // EditForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "EditForm1";
            this.Text = "EditForm1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StageNumeric1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CostNumeric1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DateTimePicker dateTimeStart1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button Savebutton1;
        private System.Windows.Forms.RichTextBox EventDesc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EventLink;
        private System.Windows.Forms.ComboBox FormComboBox;
        private System.Windows.Forms.ComboBox AgeComboBox;
        private System.Windows.Forms.Label FormIdBox;
        private System.Windows.Forms.Label AgeIdBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox TypeIdBox;
        private System.Windows.Forms.TextBox EventName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button SaveButton2;
        private System.Windows.Forms.Button DeleteButton1;
        private System.Windows.Forms.RichTextBox EventDesc2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox EventLink2;
        private System.Windows.Forms.ComboBox FormComboBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox AgeComboBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox TypeIdBox2;
        private System.Windows.Forms.TextBox EventName2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox ManagerComboBox1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RichTextBox StageDesc1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown CostNumeric1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dateTimeFinish1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox AdressComboBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown StageNumeric1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox StageName;
        private System.Windows.Forms.ComboBox EventsComboBox1;
        private System.Windows.Forms.Button SaveButtonStages1;
        private System.Windows.Forms.DateTimePicker dateTimeStart2;
        private System.Windows.Forms.DateTimePicker dateTimeFinish2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
    }
}